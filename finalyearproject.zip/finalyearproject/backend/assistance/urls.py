# assistance/urls.py
from django.urls import path
from . import views

urlpatterns = [
    # Default URL: /assistance/
    path('', views.assist_home, name='assist_home'),

    # Optional alias: /assistance/home/
    path('home/', views.assist_home, name='assist_home_home'),
]
