from django.db import models
from users.models import UserProfile

# --- Model 1: Assistance Results linked to User ---
class AssistanceResult(models.Model):
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE, related_name="assistance_results")
    assistance_required = models.BooleanField()
    suggestion = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Assistance for {self.user.user.username} ({'Required' if self.assistance_required else 'Not Required'})"

# --- Model 2: Financial Profile ---
class FinancialProfile(models.Model):
    name = models.CharField(max_length=100)
    occupation = models.CharField(max_length=100, blank=True)
    income = models.FloatField()
    expenses = models.FloatField()
    credit_score = models.IntegerField()
    savings = models.FloatField(default=0.0)
    debts = models.FloatField(default=0.0)
    monthly_investment = models.FloatField(default=0.0)
    suggestion = models.TextField(blank=True)

    def __str__(self):
        return f"{self.name} | Income: {self.income}"

# --- Model 3: Purchase Alerts from Gmail ---
class PurchaseAlert(models.Model):
    sender = models.CharField(max_length=255)
    subject = models.CharField(max_length=255)
    snippet = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Purchase Alert: {self.subject} ({self.sender})"
