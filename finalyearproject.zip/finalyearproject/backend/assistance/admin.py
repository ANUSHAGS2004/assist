# assistance/admin.py
from django.contrib import admin
from .models import AssistanceResult, FinancialProfile, PurchaseAlert


@admin.register(PurchaseAlert)
class PurchaseAlertAdmin(admin.ModelAdmin):
    list_display = ("sender", "subject", "timestamp")
    search_fields = ("sender", "subject")
    ordering = ("-timestamp",)


@admin.register(AssistanceResult)
class AssistanceResultAdmin(admin.ModelAdmin):
    list_display = ("user", "assistance_required", "suggestion", "created_at")
    list_filter = ("assistance_required", "created_at")
    search_fields = ("user__name", "suggestion")
    ordering = ("-created_at",)


@admin.register(FinancialProfile)
class FinancialProfileAdmin(admin.ModelAdmin):
    list_display = ("name", "income", "expenses", "credit_score", "suggestion")
    search_fields = ("name", "suggestion")
    ordering = ("name",)
