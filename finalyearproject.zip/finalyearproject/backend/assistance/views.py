# assistance/views.py

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .forms import FinancialProfileForm
from .models import FinancialProfile, AssistanceResult
from users.models import UserProfile
from .ml_model import predict_assistance, train_model
from users.utils import fetch_recent_transactions, generate_suggestions


@login_required(login_url="login")
def assist_home(request):
    """
    Assistance home view:
    - Shows financial profile form
    - Evaluates eligibility using ML + financial heuristics + Gmail transactions
    - Saves FinancialProfile
    - Creates linked AssistanceResult for logged-in user
    """
    if request.method == 'POST':
        form = FinancialProfileForm(request.POST)
        if form.is_valid():
            profile = form.save(commit=False)

            # --- Financial heuristics for user-friendly suggestions ---
            suggestion_messages = []

            # Net savings
            net_savings = profile.income - profile.expenses
            if net_savings > 10000:
                suggestion_messages.append("💡 Your savings are healthy. You can invest more.")
            else:
                suggestion_messages.append("⚠️ Consider reducing expenses to improve savings.")

            # Credit score advice
            if profile.credit_score >= 750:
                suggestion_messages.append("✅ Excellent credit score. Eligible for premium loans or credit cards.")
            elif 650 <= profile.credit_score < 750:
                suggestion_messages.append("⚠️ Average credit score. Improve it to get better financial options.")
            else:
                suggestion_messages.append("⚠️ Low credit score. Work on repayments to improve your score.")

            # Debts analysis
            if getattr(profile, 'debts', 0) > 0:
                suggestion_messages.append(f"⚠️ You have outstanding debts of ₹{profile.debts}. Try reducing them.")
            else:
                suggestion_messages.append("✅ No debts. Keep up the good financial health!")

            # Investments & risk tolerance
            if getattr(profile, 'monthly_investment', 0) > 0:
                suggestion_messages.append("💡 Your current investments are on track.")
            else:
                suggestion_messages.append("💡 Consider starting small investments based on your risk tolerance.")

            risk = getattr(profile, 'risk_tolerance', 'Medium')
            if risk == 'High':
                suggestion_messages.append("⚠️ High-risk tolerance. Make sure to diversify investments.")
            elif risk == 'Low':
                suggestion_messages.append("✅ Low-risk tolerance. Prefer stable investments.")

            # Monthly savings goal
            if getattr(profile, 'monthly_savings_goal', 0) > net_savings:
                suggestion_messages.append("⚠️ Your savings goal is higher than your current net savings. Adjust your budget.")

            # Financial goals
            if getattr(profile, 'financial_goals', ''):
                suggestion_messages.append(f"💡 Your financial goal: {profile.financial_goals}")

            # --- Gmail transactions analysis ---
            gmail_suggestions = []
            try:
                transactions = fetch_recent_transactions()
                if transactions:
                    gmail_suggestions = generate_suggestions(transactions)
            except Exception as e:
                print("Error fetching Gmail transactions:", e)
                gmail_suggestions.append("⚠️ Could not fetch Gmail transactions. Check Gmail API setup.")

            # Combine all suggestions for storage
            profile.suggestion = "\n".join(suggestion_messages + gmail_suggestions)

            # --- ML Prediction ---
            # Train model on historical data (optional: only first time)
            train_model(FinancialProfile.objects.all())

            # Predict assistance_required using ML
            assistance_required = predict_assistance(profile)
            if assistance_required is None:
                # fallback if model not trained
                assistance_required = net_savings <= 10000 or profile.credit_score < 700

            # Save FinancialProfile
            profile.save()

            # Save AssistanceResult linked to UserProfile
            try:
                user_profile = UserProfile.objects.get(user=request.user)
                AssistanceResult.objects.create(
                    user=user_profile,
                    assistance_required=assistance_required,
                    suggestion=profile.suggestion,
                )
            except UserProfile.DoesNotExist:
                pass

            return render(
                request,
                "assistance/result.html",
                {
                    "profile": profile,
                    "suggestions": suggestion_messages,
                    "gmail_suggestions": gmail_suggestions,
                    "ml_assistance_required": assistance_required
                }
            )
    else:
        form = FinancialProfileForm()

    return render(
        request,
        "assistance/home.html",
        {"form": form}
    )
