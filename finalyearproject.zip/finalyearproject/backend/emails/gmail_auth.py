import json
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from .models import GmailCredential  # Make sure GmailCredential model exists

# Gmail API scope (read-only)
SCOPES = ["https://www.googleapis.com/auth/gmail.readonly"]


def gmail_authenticate(user):
    """Authenticate Gmail API for a specific Django user"""
    creds = None

    try:
        cred_obj = GmailCredential.objects.get(user=user)
        # token stored as JSON string → convert back to dict
        creds = Credentials.from_authorized_user_info(json.loads(cred_obj.token), SCOPES)
    except GmailCredential.DoesNotExist:
        pass

    # If no creds or expired → refresh or login again
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            print("🔄 Refreshing expired credentials...")
            creds.refresh(Request())
        else:
            print("🌐 Opening browser for Google login...")
            flow = InstalledAppFlow.from_client_secrets_file("credentials.json", SCOPES)
            creds = flow.run_local_server(port=0)

        # Save/update credentials in DB as JSON string
        GmailCredential.objects.update_or_create(
            user=user,
            defaults={"token": creds.to_json()}
        )
        print(f"💾 Credentials saved in database for {user.username}")

    # Build Gmail API service
    service = build("gmail", "v1", credentials=creds)
    print("✅ Gmail API service created successfully for:", user.username)
    return service


def get_latest_emails(service, max_results=5):
    """Fetch latest email subjects"""
    results = service.users().messages().list(userId="me", maxResults=max_results).execute()
    messages = results.get("messages", [])
    email_subjects = []

    if not messages:
        print("📭 No messages found.")
    else:
        print(f"📩 Latest {len(messages)} emails:")
        for msg in messages:
            msg_data = service.users().messages().get(userId="me", id=msg["id"]).execute()
            headers = msg_data.get("payload", {}).get("headers", [])
            subject = next((h["value"] for h in headers if h["name"] == "Subject"), "No Subject")
            print(f"   ➡ {subject}")
            email_subjects.append(subject)

    return email_subjects
