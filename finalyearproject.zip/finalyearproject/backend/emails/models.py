from django.db import models
from django.contrib.auth.models import User

class GmailCredential(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    token = models.TextField()  # stores Gmail OAuth token JSON

    def __str__(self):
        return f"Gmail Credentials for {self.user.username}"