from gmail_auth import gmail_authenticate

service = gmail_authenticate()

# Get list of messages
results = service.users().messages().list(userId='me', maxResults=5).execute()
messages = results.get('messages', [])

if not messages:
    print("No messages found.")
else:
    print("Recent Emails:")
    for msg in messages:
        print(msg)
