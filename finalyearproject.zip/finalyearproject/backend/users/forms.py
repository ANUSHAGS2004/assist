from django import forms
from django.contrib.auth.models import User
from .models import UserProfile


class UserUpdateForm(forms.ModelForm):
    """Form to update the default Django User fields."""
    class Meta:
        model = User
        fields = ['username', 'email']


class ProfileUpdateForm(forms.ModelForm):
    """Form to update UserProfile fields."""
    class Meta:
        model = UserProfile
        fields = [
            'name',
            'phone',
            'address',
            'dob',
            'gender',
            'occupation',
            'income'
        ]
        widgets = {
            'dob': forms.DateInput(attrs={'type': 'date'}),  # calendar picker
        }
