# users/utils.py
import re
import os
from googleapiclient.discovery import build
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow

# Gmail API scope
SCOPES = ["https://www.googleapis.com/auth/gmail.readonly"]

def fetch_recent_transactions(user_email=None):
    """
    Fetch recent transactions from Gmail using Gmail API.
    Returns a list of dictionaries with clean amount, currency, and description.
    """
    creds = None
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file("credentials.json", SCOPES)
            creds = flow.run_local_server(port=0)
        with open("token.json", "w") as token:
            token.write(creds.to_json())

    service = build("gmail", "v1", credentials=creds)
    results = service.users().messages().list(userId="me", maxResults=10).execute()
    messages = results.get("messages", [])

    transactions = []
    if not messages:
        return transactions

    for msg in messages:
        msg_data = service.users().messages().get(userId="me", id=msg["id"]).execute()
        snippet = msg_data.get("snippet", "")

        # Find amounts like Rs500, ₹1000, USD 200 etc.
        matches = re.findall(r'(?:Rs|₹|USD)\s?\d+[,.]?\d*', snippet)
        for raw_amount in matches:
            numeric_str = re.sub(r"[^\d.]", "", raw_amount)
            try:
                numeric_amount = float(numeric_str)
            except ValueError:
                numeric_amount = 0.0

            # Detect currency
            if "Rs" in raw_amount or "₹" in raw_amount:
                currency = "INR"
            elif "USD" in raw_amount:
                currency = "USD"
            else:
                currency = "UNKNOWN"

            transactions.append({
                "description": snippet[:50],  # First 50 chars
                "amount": numeric_amount,
                "currency": currency
            })

    return transactions


def generate_suggestions(profile, transactions=None):
    """
    Generate financial and investment suggestions.
    profile: dict-like object with keys: income, expenses, monthly_savings_goal, debts, monthly_investment, risk_tolerance
    transactions: optional list of transaction dicts from fetch_recent_transactions
    Returns a list of suggestion strings.
    """
    suggestions = []

    income = float(profile.get("income", 0))
    expenses = float(profile.get("expenses", 0))
    savings_goal = float(profile.get("monthly_savings_goal", 0))
    debts = float(profile.get("debts", 0))
    current_investment = float(profile.get("monthly_investment", 0))
    risk = profile.get("risk_tolerance", "Medium").lower()

    # Spending check
    if expenses > income:
        suggestions.append("⚠️ Your expenses are higher than your income. Reduce non-essential spending.")
    else:
        suggestions.append("✅ Your spending is under control relative to your income.")

    # Savings check
    available_savings = income - expenses
    if available_savings < savings_goal:
        suggestions.append(f"⚠️ Your available savings (₹{available_savings:.2f}) are less than your goal (₹{savings_goal:.2f}). Try to save more.")
    else:
        suggestions.append(f"✅ You can save ₹{available_savings:.2f} this month.")

    # Debt check
    if debts > 0:
        suggestions.append(f"⚠️ You have debts totaling ₹{debts:.2f}. Prioritize paying high-interest debts first.")
    else:
        suggestions.append("✅ You are debt-free. Great job!")

    # Investment advice
    if available_savings > 0:
        if risk == "low":
            suggestions.append(f"💡 Consider safe investments like Fixed Deposits or Government Bonds with ₹{available_savings:.2f} surplus funds.")
        elif risk == "medium":
            suggestions.append(f"💡 Consider a balanced portfolio: ₹{available_savings*0.5:.2f} in mutual funds, ₹{available_savings*0.5:.2f} in safe instruments.")
        elif risk == "high":
            suggestions.append(f"💡 You can invest aggressively: ₹{available_savings*0.7:.2f} in equities or mutual funds, ₹{available_savings*0.3:.2f} in safer instruments.")
        else:
            suggestions.append(f"💡 Start basic investment plans with ₹{available_savings:.2f} in mutual funds or SIPs.")

    # Transaction-based advice
    if transactions:
        for txn in transactions:
            amt = txn.get("amount", 0.0)
            if amt > 10000:
                suggestions.append(f"⚠️ Large expense detected ({txn['currency']} {amt:.2f}): {txn['description']}. Review necessity.")
            elif amt > 5000:
                suggestions.append(f"💡 Expense of {txn['currency']} {amt:.2f}: {txn['description']}. Maybe save or invest instead?")

    if not transactions:
        suggestions.append("💡 No unusual transactions detected in recent emails.")

    # General tip
    suggestions.append("💡 Review your investments monthly and adjust according to your goals.")

    return suggestions
