from django.shortcuts import render, redirect
from django.contrib.auth import login, logout
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
from django.utils import timezone
import random

# Helper functions
from users.utils import fetch_recent_transactions, generate_suggestions
from emails.gmail_auth import gmail_authenticate, get_latest_emails

# Forms & Models
from users.forms import UserUpdateForm, ProfileUpdateForm
from users.models import UserProfile
from assistance.models import FinancialProfile

# --- Home Page ---
def home(request):
    return render(request, "users/home.html")

# --- Signup View ---
def signup_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        email = request.POST.get("email")
        password1 = request.POST.get("password1")
        password2 = request.POST.get("password2")

        if password1 != password2:
            messages.error(request, "Passwords do not match ❌")
            return redirect("signup")

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken ❌")
            return redirect("signup")

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already registered ❌")
            return redirect("signup")

        try:
            user = User.objects.create_user(username=username, email=email, password=password1)
            user.save()
            messages.success(request, "✅ Account created successfully. Please login.")
            return redirect("login")
        except Exception as e:
            messages.error(request, f"Error creating account: {str(e)}")
            return redirect("signup")

    return render(request, "users/signup.html")

# --- Login View (Email + OTP) ---
def login_view(request):
    if request.method == "POST":
        email = request.POST.get("email")
        user_qs = User.objects.filter(email=email)
        if user_qs.exists():
            user = user_qs.first()
            otp = random.randint(100000, 999999)
            request.session["otp"] = str(otp)
            request.session["user_id"] = user.id
            request.session["otp_expiry"] = (timezone.now() + timezone.timedelta(minutes=5)).isoformat()

            try:
                send_mail(
                    subject="Your Login OTP",
                    message=f"Your OTP for login is: {otp}\n\n(Valid for 5 minutes)",
                    from_email="noreply@financesystem.com",
                    recipient_list=[email],
                    fail_silently=False,
                )
                messages.success(request, f"✅ OTP sent to {email}. Please verify.")
                return redirect("verify_otp")
            except Exception as e:
                messages.error(request, f"Failed to send OTP: {str(e)}")
                return redirect("login")
        else:
            messages.error(request, "❌ Email not registered")
            return redirect("login")

    return render(request, "users/login.html")

# --- OTP Verification View ---
def verify_otp_view(request):
    if request.method == "POST":
        input_otp = request.POST.get("otp")
        session_otp = request.session.get("otp")
        user_id = request.session.get("user_id")
        otp_expiry = request.session.get("otp_expiry")

        if otp_expiry and timezone.now() > timezone.datetime.fromisoformat(otp_expiry):
            messages.error(request, "⏳ OTP expired. Please request a new one.")
            request.session.pop("otp", None)
            request.session.pop("user_id", None)
            request.session.pop("otp_expiry", None)
            return redirect("login")

        if session_otp and input_otp == session_otp:
            try:
                user = User.objects.get(id=user_id)
                login(request, user)
                request.session.pop("otp", None)
                request.session.pop("user_id", None)
                request.session.pop("otp_expiry", None)
                return redirect("dashboard")
            except User.DoesNotExist:
                messages.error(request, "User not found. Please login again.")
                return redirect("login")
        else:
            messages.error(request, "❌ Invalid OTP. Try again.")
            return redirect("verify_otp")

    return render(request, "users/verify_otp.html")

# --- Resend OTP ---
def resend_otp_view(request):
    user_id = request.session.get("user_id")
    if user_id:
        try:
            user = User.objects.get(id=user_id)
            otp = random.randint(100000, 999999)
            request.session["otp"] = str(otp)
            request.session["otp_expiry"] = (timezone.now() + timezone.timedelta(minutes=5)).isoformat()

            send_mail(
                subject="Your Login OTP",
                message=f"Your OTP for login is: {otp}\n\n(Valid for 5 minutes)",
                from_email="noreply@financesystem.com",
                recipient_list=[user.email],
                fail_silently=False,
            )
            messages.success(request, f"🔄 OTP resent to {user.email}. Please verify.")
        except User.DoesNotExist:
            messages.error(request, "User session expired. Please login again.")
            return redirect("login")
    else:
        messages.error(request, "Session expired. Please login again.")
        return redirect("login")
    return redirect("verify_otp")

# --- Update Email ---
@login_required
def update_email_view(request):
    if request.method == "POST":
        new_email = request.POST.get("email")
        if new_email:
            request.user.email = new_email
            request.user.save()
            messages.success(request, "Email updated successfully!")
            return redirect("profile")
        else:
            messages.error(request, "Please provide a valid email.")
    return render(request, "users/update_email.html")

# --- Dashboard ---
@login_required(login_url="login")
def dashboard_view(request):
    import numpy as np
    gmail_connected = False
    latest_emails = []
    unusual_alerts = []
    spending = 0
    savings = 0
    financial_profiles = None
    suggestions = []

    try:
        # Transactions
        transactions = fetch_recent_transactions(request.user)
        if transactions:
            spending = sum(float(txn.amount) for txn in transactions if hasattr(txn, "amount"))

        income = getattr(request.user.profile, "income", 0.0)
        savings = income - spending

        # --- ML-based personalized suggestions ---
        credit_score = getattr(request.user.profile, "credit_score", 650)
        avg_spending = np.mean([float(txn.amount) for txn in transactions]) if transactions else 0

        if income - avg_spending > 15000 and credit_score > 750:
            suggestions.append("💡 Great! You can consider high-return investments.")
        elif income - avg_spending > 10000 and credit_score > 700:
            suggestions.append("💡 You are doing well. Consider saving for medium-term goals.")
        elif income - avg_spending > 5000:
            suggestions.append("⚠️ Keep track of your spending to improve savings.")
        else:
            suggestions.append("⚠️ Urgent: Reduce expenses and avoid unnecessary purchases.")

        suggestions.append("💡 Regularly track your monthly expenses to improve financial health.")

        # Gmail
        try:
            service = gmail_authenticate(request.user)
            if service:
                gmail_connected = True
                latest_emails = get_latest_emails(service, max_results=5)
                unusual_keywords = ["investment", "loan", "payment", "purchase", "offer", "transaction"]
                for subj in latest_emails:
                    if any(k in subj.lower() for k in unusual_keywords):
                        unusual_alerts.append(f"⚠️ Possible unusual activity: '{subj}'")
        except Exception as e:
            print(f"Gmail error: {e}")

        # Assistance history
        financial_profiles = FinancialProfile.objects.filter(user=request.user.profile).order_by('-id')[:5]

    except Exception as e:
        transactions = []
        suggestions.append(f"⚠️ Error fetching data: {str(e)}")

    return render(request, "users/dashboard.html", {
        "transactions": transactions,
        "suggestions": suggestions,
        "gmail_connected": gmail_connected,
        "latest_emails": latest_emails,
        "alerts": unusual_alerts,
        "spending": spending,
        "savings": savings,
        "financial_profiles": financial_profiles,
    })

# --- Logout ---
@login_required
def logout_view(request):
    logout(request)
    messages.success(request, "✅ Logged out successfully.")
    return redirect("login")

# --- Profile ---
@login_required
def profile_view(request):
    profile, _ = UserProfile.objects.get_or_create(user=request.user)
    if request.method == "POST":
        u_form = UserUpdateForm(request.POST, instance=request.user)
        p_form = ProfileUpdateForm(request.POST, instance=profile)
        if u_form.is_valid() and p_form.is_valid():
            u_form.save()
            p_form.save()
            messages.success(request, "✅ Profile updated successfully!")
            return redirect("profile")
    else:
        u_form = UserUpdateForm(instance=request.user)
        p_form = ProfileUpdateForm(instance=profile)
    return render(request, "users/profile.html", {"u_form": u_form, "p_form": p_form})

# --- Assistance redirect ---
@login_required
def assistance_view(request):
    return redirect("assist_home")

# --- Gmail Connect View ---
@login_required
def connect_gmail(request):
    try:
        service = gmail_authenticate(request.user)
        if service:
            messages.success(request, "✅ Gmail connected successfully!")
        else:
            messages.error(request, "❌ Failed to connect Gmail.")
    except Exception as e:
        messages.error(request, f"Error connecting Gmail: {str(e)}")
    return redirect("dashboard")

# --- Fraud Check ---
@login_required
def fraud_check_view(request):
    return render(request, "fraud/fraud_check.html")
