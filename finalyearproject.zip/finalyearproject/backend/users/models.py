from django.db import models
from django.contrib.auth.models import User


class UserProfile(models.Model):
    """Extended profile for each User"""
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name="profile",
        null=True,
        blank=True
    )
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=15)
    occupation = models.CharField(max_length=100, blank=True)
    income = models.FloatField(default=0.0)
    address = models.TextField(blank=True, null=True)
    dob = models.DateField(blank=True, null=True)
    gender = models.CharField(
        max_length=10,
        choices=[
            ("Male", "Male"),
            ("Female", "Female"),
            ("Other", "Other")
        ],
        blank=True,
        null=True
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Profile: {self.user.username if self.user else self.name}"


class UserGoogleToken(models.Model):
    """Store Google OAuth2 token details"""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="google_token")
    access_token = models.TextField()
    refresh_token = models.TextField()
    token_uri = models.CharField(max_length=200)
    client_id = models.CharField(max_length=200)
    client_secret = models.CharField(max_length=200)
    scopes = models.TextField()

    def __str__(self):
        return f"Google Token for {self.user.username}"


class GmailCredential(models.Model):
    """Store Gmail API OAuth credentials (JSON) for each user"""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="gmail_credential")
    token = models.TextField()   # stores creds.to_json()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Gmail Credentials for {self.user.username}"
